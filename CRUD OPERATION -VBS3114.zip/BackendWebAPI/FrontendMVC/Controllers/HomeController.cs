﻿using FrontendMVC.Helper;
using FrontendMVC.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace FrontendMVC.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

       
       AmanStudentAPI _api = new AmanStudentAPI();

        public async Task<IActionResult> Index()
        {
            List<AmanStudentData> amanStudents = new List<AmanStudentData>();
            HttpClient client = _api.Initial();
            HttpResponseMessage response = await client.GetAsync("api/AmanStudent");
            if (response.IsSuccessStatusCode)
            {
                var results = response.Content.ReadAsStringAsync().Result;
                amanStudents = JsonConvert.DeserializeObject<List<AmanStudentData>>(results);
            }
            return View(amanStudents);
        }

        public async Task<IActionResult> Details(int Id)
        {
            var amanStudent = new AmanStudentData();
            HttpClient client = _api.Initial();
            HttpResponseMessage response = await client.GetAsync($"api/AmanStudent/{Id}");
            if (response.IsSuccessStatusCode)
            {
                var results = response.Content.ReadAsStringAsync().Result;
                amanStudent = JsonConvert.DeserializeObject<AmanStudentData>(results);

            }
            return View(amanStudent);
        }

        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        
        public IActionResult Create(AmanStudentData amanStudent)
        {
            HttpClient client = _api.Initial();

            //Http Post

            var postTask = client.PostAsJsonAsync<AmanStudentData>("api/AmanStudent", amanStudent);
            postTask.Wait();

            var result = postTask.Result;
            if (result.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }
            return View();
        }

        public async Task<IActionResult> Delete(int Id)
        {
            var amanStudent = new AmanStudentData();
            HttpClient client = _api.Initial();
            HttpResponseMessage response = await client.DeleteAsync($"api/AmanStudent/{Id}");
            return RedirectToAction("Index");
        }





        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
