﻿using BackendWebAPI.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BackendWebAPI.DataContext
{
 
        public class AmanStudentContext : DbContext
        {
            public AmanStudentContext(DbContextOptions<AmanStudentContext> options) : base(options)
            {

            }
            public DbSet<AmanStudent> AmanStudents { get; set; }
        }


    
}
