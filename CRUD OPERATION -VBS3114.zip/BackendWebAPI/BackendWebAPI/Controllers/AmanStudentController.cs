﻿using BackendWebAPI.DataContext;
using BackendWebAPI.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BackendWebAPI.Controllers
{
    [Route("api/[Controller]")]

    public class AmanStudentController : Controller
    {



        private AmanStudentContext _context;
        public AmanStudentController(AmanStudentContext context)
        {
            _context = context;
        }
        //Get all the User list from the table of DeepakUsers from the database.
        [HttpGet]
        public List<AmanStudent> Get()
        {
            return _context.AmanStudents.ToList();
        }
        [HttpGet("{Id}")]
        public AmanStudent GetAmanStudent(int Id)
        {
            var amanStudent = _context.AmanStudents.Where(a => a.StudentID == Id).FirstOrDefault();
            return amanStudent;
        }

        [HttpPost]
        public IActionResult PostAmanStudent([FromBody] AmanStudent amanStudent)
        {
            if (!ModelState.IsValid)
                return BadRequest("Not a valid Model");

            _context.AmanStudents.Add(amanStudent);
            _context.SaveChanges();

            return Ok();
        }

        [HttpDelete("{Id}")]
        public async Task<IActionResult> DeleteAmanStudent(int Id)
        {
            var amanStudent = await _context.AmanStudents.FindAsync(Id);
            if (amanStudent == null)
            {
                return NotFound();
            }
            _context.AmanStudents.Remove(amanStudent);
            await _context.SaveChangesAsync();

            return NoContent();
        }
        [HttpPut("{Id}")]
        public async Task<IActionResult> UpdateAmanStudent(int Id,[FromBody] AmanStudent amanStudent)
        {
            if (Id != amanStudent.StudentID)
            {
                return BadRequest("Id mishmatch");
            }
            var student =await _context.AmanStudents.FindAsync(Id);
            if (student != null)
            {
                 _context.AmanStudents.Update(amanStudent);
                await _context.SaveChangesAsync();
            }
            return NoContent();

        }

    }
}
